import {
    AfterViewInit,
    Component,
    OnDestroy,
    OnInit,
    ViewChild,
  } from '@angular/core';
  import { DomSanitizer } from '@angular/platform-browser';
  import { Router } from '@angular/router';
  import { DataTableDirective } from 'angular-datatables';
  import { NgxSpinnerService } from 'ngx-spinner';
  import { promise } from 'protractor';
  import { Subject } from 'rxjs';
  import { LoggerService } from 'src/app/shared/services/logger.service';
  import { SessionService } from 'src/app/shared/services/session.service';
  import { ToasterService } from 'src/app/shared/services/toaster.service';
  import { UtilsService } from 'src/app/shared/services/utils.service';
  import { StateService } from 'src/app/stateLevel/services/state.service';
   
  
  @Component({
    selector: 'app-job-details-reports',
    templateUrl: './job-details-reports.component.html',
    styleUrls: ['./job-details-reports.component.css']
  })
  export class JobDetailsReportsComponent implements OnInit {
  
  
    jobDetailsList = [];
    reportTotals = {
        S_NO: '-',
        REGISTRATION_ID: '-',
        NAME: '-',
        FATHER_OR_MOTHER_NAME: '-',
        GENDER: '-',
        DOB: '-',
        EMAIL_ID: '-',
        MOBILE_NUMBER: '-'
    };
    excelData = [];
  
    @ViewChild(DataTableDirective, { static: false })
    dtElement: DataTableDirective;
  
    dtOptions: DataTables.Settings = this.utils.dataTableOptions();
    dtTrigger: Subject<any> = new Subject();
  
    constructor(
        private spinner: NgxSpinnerService,
        private toast: ToasterService, 
        private utils: UtilsService,
        private logger: LoggerService,
        private session: SessionService,
        private stateapi: StateService,
    ) { }
  
    ngOnInit(): void {
        debugger;
        this.session.masterId = sessionStorage.getItem('masterId');
        this.loadReport();
    }
  
    async loadReport(): Promise<void> {
        try { 
            const req = {
                type: "27",  
                MASTER_ID:this.session.masterId,           
            };debugger;
            console.log(req);
            this.spinner.show();
            const res = await this.stateapi.NotificationsForJobDetails(req);
            if (res.success) { 
              this.excelData = [];
             this.jobDetailsList = res.result; 
             this.excelData=res.result; 
            }
             else { 
                this.toast.info(res.message);
            }
            //this.rerender();
            this.spinner.hide();
        } catch (error) {
            this.spinner.hide();
            this.utils.catchResponse(error);
        }
    }
  
    btnExcel(): void {
        this.utils.JSONToCSVConvertor(
            this.excelData,
            'Job Details Report',
            true
        );
    } 
  
    ngOnDestroy(): void {
      // Do not forget to unsubscribe the event
      this.dtTrigger.unsubscribe();
    }
  
    ngAfterViewInit(): void {
      this.dtTrigger.next();
    }
  
    rerender(): void {
      this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
        // Destroy the table first
        dtInstance.destroy();
        // Call the dtTrigger to rerender again
        this.dtTrigger.next();
      });
    }
  }
  