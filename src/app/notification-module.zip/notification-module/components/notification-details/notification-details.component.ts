import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';  
import { SessionService } from 'src/app/shared/services/session.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { UtilsService } from 'src/app/shared/services/utils.service';
import { StateService } from 'src/app/stateLevel/services/state.service';

@Component({
  selector: 'app-notification-details',
  templateUrl: './notification-details.component.html',
  styleUrls: ['./notification-details.component.css']
})
export class NotificationDetailsComponent implements OnInit {
    private hasClicked = false;
    isnumberofpersons: boolean = false;
    isexpequal: boolean = false;
    isexpequalone: boolean = false;
    isCardClosed: boolean = false;      
    DataArray = [];
    DesiList: any[] = [];
    POSITIONLIST: any[] = [];
    SUBLIST: any[] = [];

    reqobj = {
        designation: '', 
        Position:'',  
      };
 
    constructor(
        private amulurl: StateService, 
        private spinner: NgxSpinnerService,
       private utils: UtilsService,
        private toast: ToasterService,
        private session: SessionService,
        private router: Router,
    ) { }
    
    ngOnInit(): void { 
        this.LoadDesi();
        
    } 
async handleMouseEnter(obj:any): Promise<void> {     
    try  {
              const req = {
                  TYPE: "14",
                  STATUS:obj.POSITION_ID                 
              }
              debugger; 
              const res = await this.amulurl.NotificationsForJobDetails(req);
              if (res.success) {                  
                  this.SUBLIST = res.result;
               console.log(this.SUBLIST);
        
              } else {
                  this.spinner.hide();
                 this.toast.info(res.message);
              }
        
          } catch (error) {
              this.spinner.hide();
             this.utils.catchResponse(error);
          } 
  }

     
    async DesignationClick(obj:any): Promise<void> { 
         
          try 
          {

            this.reqobj = {
                designation:obj.DESIGNATION, 
                Position:obj.POSITION,               
              };

        const req = {
            TYPE: "11",
            DESI_ID:obj.DESI_ID            
        }
        debugger;
        this.spinner.show();
        const res = await this.amulurl.NotificationsForJobDetails(req);
        if (res.success) {
            this.spinner.hide();
            this.POSITIONLIST = res.result;
            this.isexpequalone = true;
         console.log(this.POSITIONLIST);

        } else {
            this.spinner.hide();
           this.toast.info(res.message);
        }

    } catch (error) {
        this.spinner.hide();
       this.utils.catchResponse(error);
    }


    }
    closeCard() {
        this.isCardClosed = true;
        this.isexpequalone = false;
    }
    
    GoTopage(ob:any) {
         

            // this.router.navigate(['/NotificationModule/RegistrationDetails'], {
                 
            //    });
            debugger;
            this.router.navigate(['/NotificationModule/RegistrationDetails'], {
                queryParams: { data: JSON.stringify(ob) }
            });
    

    }
 
    async LoadDesi(): Promise<void> {
        try {
            const req = {
                TYPE: "10", 
            }
            debugger;
            this.spinner.show();
            const res = await this.amulurl.NotificationsForJobDetails(req);
            if (res.success) {
                this.spinner.hide();
                this.DesiList = res.result;
             console.log(this.DesiList);

            } else {
                this.spinner.hide();
               this.toast.info(res.message);
            }

        } catch (error) {
            this.spinner.hide();
            this.utils.catchResponse(error);
        }

    }

}

